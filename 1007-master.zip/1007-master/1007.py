a = int(input())
b = int(input())
c = int(input())
d = int(input())

diferenca = (a*b - c*d)

print("DIFERENCA =", diferenca)